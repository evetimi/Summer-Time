//
//
//
// MACHINE-GENERATED CODE - DO NOT MODIFY BY HAND!
//
// NOTE: You definitely SHOULD commit this file to source control!!!
//
//
// To regenerate this file, select any Datasack object, look
// in the custom Inspector window and press the CODEGEN button.
//
//
//
public partial class DSM
{

// Datasacks from directory 'Assets/ProcGenStuff/SpawningEvenlyAcross/Datasacks/SpawningEvenlyAcross'
	public static partial class SpawningEvenlyAcross
	{
		public static Datasack DistributionStrategy { get { return DSM.I.Get( "SpawningEvenlyAcross/DistributionStrategy"); } }
		public static Datasack DistributionStrategyText { get { return DSM.I.Get( "SpawningEvenlyAcross/DistributionStrategyText"); } }
		public static Datasack ItemCount { get { return DSM.I.Get( "SpawningEvenlyAcross/ItemCount"); } }
	}

// Datasacks from directory 'Assets/TerrainStuff/TerrainByPerlinNoise/Datasacks/Perlin'
	public static partial class Perlin
	{
		public static Datasack VerticalScale { get { return DSM.I.Get( "Perlin/VerticalScale"); } }
		public static Datasack XFrequency { get { return DSM.I.Get( "Perlin/XFrequency"); } }
		public static Datasack XOffset { get { return DSM.I.Get( "Perlin/XOffset"); } }
		public static Datasack YFrequency { get { return DSM.I.Get( "Perlin/YFrequency"); } }
		public static Datasack YOffset { get { return DSM.I.Get( "Perlin/YOffset"); } }
	}

// Datasacks from directory 'Assets/TerrainStuff/TerrainDamager/UI/Datasacks'

	// Persistent (has .Save field checked in Datasack):
	public static Datasack SelectedWeapon { get { return DSM.I.Get( "SelectedWeapon"); } }

}

// Total of 9 datasacks found and processed.
