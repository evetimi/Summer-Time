﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Miscellaneous1 : MonoBehaviour
{
	void Start ()
	{
		MakeStuff.MakeSpiralStairs();
	}
}
