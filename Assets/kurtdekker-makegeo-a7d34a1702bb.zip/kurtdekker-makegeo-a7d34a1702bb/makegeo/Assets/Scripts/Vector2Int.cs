﻿
// later versions of Unity have a better version of this so
// comment this struct out if your version has it...

public struct Vector2Int
{
	public int x;
	public int y;

	public Vector2Int(int x = 0, int y = 0)
	{
		this.x = x;
		this.y = y;
	}
}
