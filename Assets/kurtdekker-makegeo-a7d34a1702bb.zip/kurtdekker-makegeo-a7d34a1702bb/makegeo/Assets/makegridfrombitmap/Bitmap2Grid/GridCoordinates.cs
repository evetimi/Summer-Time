﻿using UnityEngine;

// @kurtdekker - put this on objects that need to later tell
// you what their cell / grid coordinates are.

public class GridCoordinates : MonoBehaviour
{
	public int CellX;
	public int CellY;
}
