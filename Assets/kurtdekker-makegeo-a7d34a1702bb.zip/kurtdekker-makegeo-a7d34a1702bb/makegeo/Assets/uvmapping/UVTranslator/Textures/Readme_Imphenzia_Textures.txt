NOTE: The textures beginning with "Imphenzia" are not mine.

Textures beginning with "Imphenzia" are from @Imphenzia:

www.twitter.com/imphenzia

https://www.youtube.com/channel/UCzfWju7SFoWLCyV_gDVCrGA
