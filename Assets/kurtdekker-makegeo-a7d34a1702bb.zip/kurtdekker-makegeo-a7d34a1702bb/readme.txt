.LOG

7:45 AM 3/2/2018

Make Geometry repository. This is a place I'll fiddle around
with various procedural geometry stuff. Help yourself if you
find it useful!!

Kurt Dekker

You can check out my games here:

iPhone:  https://itunes.apple.com/us/developer/kurt-dekker/id680019078
Android: https://play.google.com/store/apps/developer?id=Kurt+Dekker

Also: https://kurtdekker.itch.io/
